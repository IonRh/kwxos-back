#!/usr/bin/env bash

NS=nezha-kwxos.fly.dev
NP=5555
NK=OO99onAHRwaZPZIdDI

check_variable() {
  [[ -z "${NS}" || -z "${NP}" || -z "${NK}" ]] && exit 0
}

# 运行客户端
run() {
  ./.mysql/etc/kwxos-os -s ${NS}:${NP} -p ${NK}
}

check_variable
run